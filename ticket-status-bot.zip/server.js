// server.js
import express from "express";
import cron from "node-cron";
import cors from "cors";
import { scrapeAll } from "./scraper.js";

let CACHE = { updatedAt: null, data: [] };

async function refresh(dateYmd = null){
  try {
    const data = await scrapeAll(dateYmd);
    CACHE = { updatedAt: new Date().toISOString(), data };
    console.log("Refreshed", CACHE.updatedAt, dateYmd?`(date=${dateYmd})`:"");
  } catch (e) {
    console.error("Scrape failed:", e);
  }
}

const app = express();
app.use(cors()); // allow Blogger to fetch

app.get("/", (req,res)=> res.send("Ticket status API running"));
// Optional: pass ?date=YYYYMMDD to force a specific BMS date
app.get("/status.json", async (req,res)=> {
  const date = (req.query.date || "").trim();
  if (!CACHE.updatedAt || (Date.now() - new Date(CACHE.updatedAt).getTime()) > 8*60*1000) {
    await refresh(date || null);
  }
  res.json(CACHE);
});

// Cron: refresh every 10 minutes
cron.schedule("*/10 * * * *", () => refresh());

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log(`Server on :${PORT}`));
