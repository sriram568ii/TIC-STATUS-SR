# Ticket Status Bot (BookMyShow + TicketNew)

Scrapes ticket status/showtimes and exposes `/status.json` for your Blogger widget.

## Quick Start (Local)
```bash
npm install
node server.js
# Open http://localhost:3000/status.json
```

## Deploy (Render.com - recommended)
1. Create a new Web Service from this folder/repo.
2. Build: `npm install`
3. Start: `node server.js`
4. After deploy, your API URL will be:
   `https://<your-app>.onrender.com/status.json`

## API
- `GET /status.json` → cached result (refresh every 10 minutes).
- Optional: `GET /status.json?date=YYYYMMDD` to set BookMyShow date for the fetch cycle.

## Edit Targets
- See `scraper.js` → `TARGETS` array (already filled for Coolie @ TicketNew + BookMyShow).
- Add more movies/cities by pushing entries into `TARGETS`.

## Blogger Widget
Use your existing widget and set:
```js
const API_URL = "https://<your-app>.onrender.com/status.json";
```

## Heads up
- Heavy JS sites; Playwright waits for network idle.
- Update regex keywords if their UI text changes.
- Respect site ToS.
