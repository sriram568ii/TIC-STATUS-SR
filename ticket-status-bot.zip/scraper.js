// scraper.js
import { chromium } from "playwright";

// ========= CONFIG =========
export const TARGETS = [
  {
    movie: "Coolie",
    source: "TicketNew",
    city: "chennai",
    url: "https://ticketnew.com/movies/coolie-movie-detail-172677?frmtid=zcw3aqxszc",
    poster: "https://blogger.googleusercontent.com/img/a/AVvXsEj6FVC7yJVclnxtmOdTheOGwPcT2CiLWQDeY4tyXrkBzy5_IuZyUXR-lnsfuzITvUIDq3VvVDw-eh4ONPSYruglM2r4lH1h-AxGZpv_iWH5sMFaGDLMvZ_C3a8O6zusnkGaFDl9EZeUchQX_89hCu9M5uc4FxeIapvZA0__-f2NhwLooJhy5SkkKxr_PV8=w1000"
  },
  {
    movie: "Coolie",
    source: "BookMyShow",
    city: "chennai",
    // BMS date format = YYYYMMDD (dynamic by default; override with ?date=YYYYMMDD on the API if you want)
    url: bmsUrlFor(),
    poster: "https://blogger.googleusercontent.com/img/a/AVvXsEj6FVC7yJVclnxtmOdTheOGwPcT2CiLWQDeY4tyXrkBzy5_IuZyUXR-lnsfuzITvUIDq3VvVDw-eh4ONPSYruglM2r4lH1h-AxGZpv_iWH5sMFaGDLMvZ_C3a8O6zusnkGaFDl9EZeUchQX_89hCu9M5uc4FxeIapvZA0__-f2NhwLooJhy5SkkKxr_PV8=w1000"
  }
];

const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36";

const KEYWORDS = {
  open: /book\s*now|tickets?\s*available|reserve/i,
  fast: /fast\s*filling|filling\s*fast|few\s*seats/i,
  full: /house\s*full|sold\s*out|no\s*seats/i,
  soon: /coming\s*soon|not\s*available|sales\s*not\s*started|unavailable/i
};
const TIME_RX = /^\d{1,2}:\d{2}\s*(AM|PM)?$/i;
const DEDUPE = (arr)=> [...new Set(arr.filter(Boolean).map(s=>s.trim()))];

// Helper to build BMS URL for today in IST unless dateYmd is passed
export function bmsUrlFor(dateYmd=""){
  const now = new Date();
  // Convert to IST by adding 5.5 hours offset from UTC relative to local time
  const istMillis = now.getTime() + (5.5 * 60 * 60 * 1000);
  const ist = new Date(istMillis);
  const y = ist.getUTCFullYear();
  const m = String(ist.getUTCMonth()+1).padStart(2,"0");
  const d = String(ist.getUTCDate()).padStart(2,"0");
  const ymd = dateYmd || `${y}${m}${d}`;
  return `https://in.bookmyshow.com/movies/chennai/coolie/buytickets/ET00395817/${ymd}`;
}

// ========= SCRAPERS =========
async function scrapeBMS(page, url){
  await page.goto(url, { waitUntil: "domcontentloaded", timeout: 60000 });
  await page.waitForLoadState("networkidle", { timeout: 45000 }).catch(()=>{});

  // Close popups where possible
  await page.locator('button:has-text("Accept")').first().click({ timeout: 3000 }).catch(()=>{});
  await page.locator('button:has-text("Allow")').first().click({ timeout: 3000 }).catch(()=>{});

  const html = await page.content();

  let status = "Unknown";
  if (KEYWORDS.full.test(html))      status = "Housefull";
  else if (KEYWORDS.fast.test(html)) status = "Fast Filling";
  else if (KEYWORDS.open.test(html)) status = "Bookings Open";
  else if (KEYWORDS.soon.test(html)) status = "Not Open";

  const shows = await page.$$eval('a,button,span,div', els =>
    [...els].map(e => (e.textContent||"").trim()).filter(t => /^\d{1,2}:\d{2}\s*(AM|PM)?$/i.test(t))
  ).catch(()=>[]);

  return { status, shows: DEDUPE(shows) };
}

async function scrapeTicketNew(page, url){
  await page.goto(url, { waitUntil: "domcontentloaded", timeout: 60000 });
  await page.waitForLoadState("networkidle", { timeout: 45000 }).catch(()=>{});

  const html = await page.content();

  let status = "Unknown";
  if (KEYWORDS.full.test(html))      status = "Housefull";
  else if (KEYWORDS.fast.test(html)) status = "Fast Filling";
  else if (KEYWORDS.open.test(html)) status = "Bookings Open";
  else if (KEYWORDS.soon.test(html)) status = "Not Open";

  const shows = await page.$$eval('a,button,span,div', els =>
    [...els].map(e => (e.textContent||"").trim()).filter(t => /^\d{1,2}:\d{2}\s*(AM|PM)?$/i.test(t))
  ).catch(()=>[]);

  return { status, shows: DEDUPE(shows) };
}

// ========= MAIN =========
export async function scrapeAll(dateYmdFromQuery = null){
  const browser = await chromium.launch({ headless:true, args:["--disable-dev-shm-usage"] });
  const ctx = await browser.newContext({ userAgent: UA, viewport:{ width:1280, height:900 } });

  // If API query sets ?date=YYYYMMDD, refresh the BMS target URL accordingly
  if (dateYmdFromQuery) {
    for (const t of TARGETS) {
      if (t.source === "BookMyShow") t.url = bmsUrlFor(dateYmdFromQuery);
    }
  }

  const out = [];
  for (const t of TARGETS){
    const page = await ctx.newPage();
    let result = { movie:t.movie, source:t.source, url:t.url, ok:true, error:null, status:"Unknown", shows:[], poster:t.poster||"" };

    try {
      if (t.source === "BookMyShow") result = { ...result, ...(await scrapeBMS(page, t.url)) };
      else if (t.source === "TicketNew") result = { ...result, ...(await scrapeTicketNew(page, t.url)) };
      else throw new Error("Unknown source: "+t.source);

    } catch (e){
      result.ok = false;
      result.error = e.message;
    }
    result.fetchedAt = new Date().toISOString();
    out.push(result);
    await page.close();
  }

  await ctx.close();
  await browser.close();
  return out;
}

// CLI
if (import.meta.url === `file://${process.argv[1]}`) {
  const args = process.argv.slice(2);
  const dateArg = args.find(a => a.startsWith("--date="));
  const dateYmd = dateArg ? dateArg.split("=")[1] : null;
  scrapeAll(dateYmd).then(r => console.log(JSON.stringify(r,null,2)));
}
